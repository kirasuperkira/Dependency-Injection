﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using BusinessLogic;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        private Logic logic = new Logic();
        public Form1()
        {
            InitializeComponent();
        }

        private void Add_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(Name.Text) &&
                !string.IsNullOrWhiteSpace(Speciality.Text) &&
                !string.IsNullOrWhiteSpace(Group.Text))
            {
                string name = Name.Text;
                string speciality = Speciality.Text;
                string group = Group.Text;
                logic.AddStudent(name, speciality, group);

                Name.Clear();
                Speciality.Clear();
                Group.Clear();
            }
            else
            {
                MessageBox.Show("Ошибка ввода данных! Заполните все поля!");
            }
        }
    }
}
