﻿CREATE TABLE [dbo].[Students]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [Name] NCHAR(10) NULL, 
    [Speciality] NCHAR(10) NULL, 
    [Group] NCHAR(10) NULL
)
