﻿using System.Collections.Generic;

namespace Model
{
    public interface IRepository<T> where T : IDomainObject, new()
    {
        /// <summary>
        /// Создание нового объекта T в базе данных
        /// </summary>
        /// <param name="obj"></param>
        void Create(T obj);

        /// <summary>
        /// Получение всех объектов T из базы данных
        /// </summary>
        /// <returns></returns>
        IEnumerable<T> ReadAll();

        /// <summary>
        /// Возвращение объекта T по Id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        T ReadById(int id);

        /// <summary>
        /// Обновление объекта T в базе данных
        /// </summary>
        /// <param name="obj"></param>
        void Update(T obj);

        /// <summary>
        /// Удаление объекта T из базы данных
        /// </summary>
        /// <param name="obj"></param>
        void Delete(T obj);
    }
}