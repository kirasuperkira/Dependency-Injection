﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;
using System.Data.Entity;


namespace DataAccessLayer
{
    public class Context : DbContext
    {
        public DbSet<Student> Students { get; set; }
        public Context() : base("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\Кира\\source\\repos\\АИС\\lab3\\source\\DataAccessLayer\\Database1.mdf;Integrated Security=True")
        {
            try
            {
                Database.SetInitializer(new CreateDatabaseIfNotExists<Context>());
                Database.SetInitializer(new DropCreateDatabaseIfModelChanges<Context>());
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка подключения к базе данных: {ex.Message}");
            }
        }
    }

    public class EntityRepository : IRepository<Student>
    {
        private readonly Context context = new Context();

        /// <summary>
        /// Добавление нового студента
        /// </summary>
        /// <param name="student"></param>
        public void Create(Student student)
        {
            context.Students.Add(student);
            context.SaveChanges();
        }

        /// <summary>
        /// Считывание всех запсией, список студентов
        /// </summary>
        /// <returns></returns>
        public IEnumerable<Student> ReadAll()
        {
            return context.Students.ToList();
        }

        /// <summary>
        /// Считывание студента по идентификатору
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Student ReadById(int id)
        {
            return context.Students.Where(o => o.Id == id).FirstOrDefault();
        }

        /// <summary>
        /// Обновление списка студентов, его выгрузка из базы данных
        /// </summary>
        /// <param name="student"></param>
        public void Update(Student student)
        {
            var origin = context.Students.Where(o => o.Id == student.Id).FirstOrDefault();
            if (origin != null)
            {
                origin.Name = student.Name;
                origin.Speciality = student.Speciality;
                origin.Group = student.Group;
                context.SaveChanges();
            }
        }

        /// <summary>
        /// Удаление студента из базы
        /// </summary>
        /// <param name="student"></param>
        public void Delete(Student student)
        {
            context.Students.Remove(student);
            context.SaveChanges();
        }
    }
}