﻿using System.Collections.Generic;
using System.Linq;
using Model;
using Dapper;
using System.Data;
using System.Data.SqlClient;

namespace DataAccessLayer
{
    public class DapperRepository : IRepository<Student>
    {
        private string connectionString;

        public DapperRepository()
        {
            this.connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\Кира\\source\\repos\\АИС\\lab3\\source\\DataAccessLayer\\Database1.mdf;Integrated Security=True";
        }

        /// <summary>
        /// Работа с SQL запросами
        /// </summary>
        /// <param name="script"></param>
        private void UseScript(string script)
        {
            if (!string.IsNullOrEmpty(script))
            {
                using (IDbConnection db = new SqlConnection(connectionString))
                {
                    db.Execute(script);
                }
            }
        }

        /// <summary>
        /// Добавление нового студента
        /// </summary>
        /// <param name="student"></param>
        public void Create(Student student)
        {
            string script = "INSERT INTO Students VALUES(N'" + student.Name + "', N'" + student.Group + "', N'" + student.Speciality + "')";
            UseScript(script);
        }

        /// <summary>
        ///Удаление студента по идентификатору
        /// </summary>
        /// <param name="student"></param>
        public void Delete(Student student)
        {
            string script = "DELETE FROM Students WHERE Id = " + student.Id;
            UseScript(script);
        }

        /// <summary>
        /// Получение списка студентов
        /// </summary>
        /// <returns></returns>
        public IEnumerable<Student> ReadAll()
        {
            List<Student> students;
            using (IDbConnection db = new SqlConnection(connectionString))
            {
                students = db.Query<Student>("SELECT * FROM Students ").ToList();
            }
            return students;
        }

        /// <summary>
        /// Получение идентификатора студента
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Student ReadById(int id)
        {
            Student student;
            using (IDbConnection db = new SqlConnection(connectionString))
            {
                student = db.Query<Student>("SELECT * FROM Students WHERE Id = " + id).FirstOrDefault();
            }
            return student;
        }

        /// <summary>
        /// Обновление списка студентов
        /// </summary>
        /// <param name="student"></param>
        public void Update(Student student)
        {
            string script = "UPDATE Students SET (Name = '" + student.Name + "', Group = '" + student.Group + "', Speciality = '" + student.Speciality + "') WHERE Id = " + student.Id;
            UseScript(script);
        }
    }
}