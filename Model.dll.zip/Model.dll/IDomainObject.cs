﻿namespace Model
{
    public interface IDomainObject
    {
        int Id { set; get; }
    }
}
