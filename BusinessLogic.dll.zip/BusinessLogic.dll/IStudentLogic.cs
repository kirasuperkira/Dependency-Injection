﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogic
{
    public interface IStudentLogic
    {
        /// <summary>
        /// Добавление студента
        /// </summary>
        /// <param name="name">Имя добавляемого студента</param>
        /// <param name="speciality">Специальность добавляемого студента</param>
        /// <param name="group">Группа добавляемого студента</param>
        void AddStudent(string name, string speciality, string group);

        /// <summary>
        /// Удаление студента
        /// </summary>
        /// <param name="name">Имя удаляемого студента</param>
        bool DeleteStudent(string name);

        /// Изменение студента
        /// </summary>
        /// <param name="name">Имя изменяемого студента</param>
        /// <param name="newName">Новое имя для изменяемого студента</param>
        /// <param name="newGroup">Новая группа для изменяемого студента</param>
        /// <param name="newSpeciality">Новая специальность для изменяемого студента</param>
        /// /// <returns>Возвращение измененного студента</returns>
        bool EditStudent(string name, string newName, string newSpeciality, string newGroup);

        /// <summary>
        /// Возвращение списка всех студентов-словарей
        /// </summary>
        /// <returns>Возвращение списка словарей-студентов</returns>
        List<Dictionary<string, string>> GetAllStudents();

        /// <summary>
        /// Получение данных для гистограммы
        /// </summary>
        /// <returns>Возвращение гистограммы</returns>
        Dictionary<string, int> GetSpecialityHistogram();
    }
}
