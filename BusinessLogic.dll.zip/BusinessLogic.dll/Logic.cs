﻿using System;
using System.Collections.Generic;
using System.Linq;
using Model;
using DataAccessLayer;

namespace BusinessLogic
{
    public class Logic : IStudentLogic
    {
        //Избавление от композиции в пользу агрегации в классе Logic
        public IRepository<Student> repository { get; set; }

        public Logic(IRepository<Student> Repository)
        {
            repository = Repository;
        }

        public IRepository<Student> Repository { get => Repository; set => Repository = value; }

        /// <summary>
        /// Добавление студента
        /// </summary>
        /// <param name="name">Имя добавляемого студента</param>
        /// <param name="speciality">Специальность добавляемого студента</param>
        /// <param name="group">Группа добавляемого студента</param>
        public void AddStudent(string name, string speciality, string group)
        {
            repository.Create(new Student { Name = name, Speciality = speciality, Group = group });
        }

        /// <summary>
        /// Удаление студента
        /// </summary>
        /// <param name="idStudent">Идентификатор удаляемого студента</param>
        public bool DeleteStudent(string idStudent)
        {
            if (int.TryParse(idStudent, out int id))
            {
                var student2 = repository.ReadById(id);

                if (student2 != null)
                {
                    repository.Delete(student2);
                    return true;
                }
                return false;
            }
            return false;
        }

        /// <summary>
        /// Изменение студента
        /// </summary>
        /// <param name="idStudent">Идентификатор студента, которого нужно изменить</param>
        /// <param name="newName">Новое имя для изменяемого студента</param>
        /// <param name="newSpeciality">Новая специальность для изменяемого студента</param>
        /// <param name="newGroup">Новая группа для изменяемого студента</param>
        public bool EditStudent(string idStudent, string newName, string newSpeciality, string newGroup)
        {
            if (int.TryParse(idStudent, out int id)) //Преобразование строки в int. возвращение логического значения
            {
                var student = repository.ReadById(id);

                if (student != null)
                {
                    student.Name = newName;
                    student.Speciality = newSpeciality;
                    student.Group = newGroup;

                    repository.Update(student);
                    return true;
                }
                return false;
            }
            return false;
        }

        /// <summary>
        /// Возвращение списка всех студентов-словарей
        /// </summary>
        /// <returns>Возвращение списка словарей-студентов</returns>
        public List<Dictionary<string, string>> GetAllStudents()
        {
            var studentList = new List<Dictionary<string, string>>();
            var students1 = repository.ReadAll();

            foreach (var student in students1)
            {
                var studentDictionary = new Dictionary<string, string>
                {
                    { "Name", student.Name },
                    { "Speciality", student.Speciality },
                    { "Group", student.Group },
                    { "Id", student.Id.ToString() } 
                };
                studentList.Add(studentDictionary);
            }
            return studentList;
        }

        /// <summary>
        /// Получение данных для гистограммы
        /// </summary>
        /// <returns>Возвращение гистограммы</returns>
        public Dictionary<string, int> GetSpecialityHistogram()
        {
            var students = repository.ReadAll();

            Dictionary<string, int> histogram = new Dictionary<string, int>(); //Инициализация словаря

            foreach (var student in students)
            {
                string speciality = student.Speciality;

                if (histogram.TryGetValue(speciality, out int count))//Если специальность уже внесена в словарь, увеличиваем счетчик; out - выходной параметр (метод задает значение аргумента)
                {
                    histogram[speciality] = count + 1;
                }
                else
                {
                    histogram[speciality] = 1;
                }
            }
            return histogram;
        }
    }
}