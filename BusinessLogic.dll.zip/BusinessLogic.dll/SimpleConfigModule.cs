﻿using Model;
using Ninject.Modules;
using DataAccessLayer;

namespace BusinessLogic
{
    /// <summary>
    /// Конфигурационный модуль настраивает зависимости для интерфейсов репозитория и логики работы со студентами.
    /// Установление сопоставления между интерфейсом-зависимостью и конкретным классом этого интерфейса
    /// </summary>
    public class SimpleConfigModule : NinjectModule
    {
        /// <summary>
        /// Определение зависимотей для объектов приложения
        /// </summary>
        public override void Load()
        {
            Bind<IRepository<Student>>().To<EntityRepository>().InSingletonScope();
            //Bind<IRepository<Student>>().To<DapperRepository>().InSingletonScope();
            Bind<IStudentLogic>().To<Logic>().InSingletonScope();
        }
    }
}
