﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusinessLogic;
using Ninject;
using System.Threading;

namespace ConsoleApp1
{
    internal class Program
    {
        /// <summary>
        /// Выбор команды
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            //Для управления зависимостями через Ninject создаю объект Ninject.IKernel с помощью встроенной реализации этого интерфейса - класса StandardKernel
            IKernel ninjectKernel = new StandardKernel(new SimpleConfigModule());
            IStudentLogic logic = ninjectKernel.Get<IStudentLogic>();

            while (true)
            {
                Console.WriteLine("1 - Добавить студента");
                Console.WriteLine("2 - Удалить студента");
                Console.WriteLine("3 - Изменить студента");
                Console.WriteLine("4 - Вывести список студентов");
                Console.WriteLine("5 - Гистограмма (распределение по специальностям)");

                var choice = Console.ReadKey().KeyChar;
                Console.WriteLine();

                switch (choice)
                {
                    /// <summary>
                    /// Добавление нового студента
                    /// </summary>
                    case '1':
                        Console.WriteLine("Введите имя студента: ");
                        var name = Console.ReadLine();
                        Console.WriteLine("Введите специальность студента: ");
                        var speciality = Console.ReadLine();
                        Console.WriteLine("Введите группу студента: ");
                        var group = Console.ReadLine();
              
                        logic.AddStudent(name, speciality, group);
                        Console.WriteLine("Студент добавлен. Обновите таблицу, используя команду 4.");
                        break;

                    /// <summary>
                    /// Удаление студента
                    /// </summary>
                    case '2':
                        Console.WriteLine("Введите идентификатор студентакоторого вы хотите удалить: ");
                        var id = Console.ReadLine();
                        if (logic.DeleteStudent(id))
                        {
                            Console.WriteLine("Студент удален. Обновите таблицу, используя команду 4.");
                        }
                        else
                        {
                            Console.WriteLine("Студент с данным идентификатором не найден в таблице.");
                        }
                        break;

                    /// <summary>
                    /// Изменение данных студента
                    /// </summary>
                    case '3':
                        Console.WriteLine("Введите идентификатор студента, которого вы хотите изменить: ");
                        var id1 = Console.ReadLine();

                        Console.WriteLine("Введите новые данные о студенте:");
                        Console.WriteLine("Имя студента: ");
                        var newName = Console.ReadLine();
                        Console.WriteLine("Специальность студента: ");
                        var newSpeciality = Console.ReadLine();
                        Console.WriteLine("Группа студента: ");
                        var newGroup = Console.ReadLine();

                        if (logic.EditStudent(id1, newName, newSpeciality, newGroup))
                        {
                            Console.WriteLine("Данные студента изменены. Обновите таблицу, используя команду 4.");
                        }
                        else
                        {
                            Console.WriteLine("Сткдент с данным идентификатором отсутсвует в таблице.");
                        }
                        break;

                    /// <summary>
                    /// Вывод таблицы студентов
                    /// </summary>
                    case '4':
                        var students = logic.GetAllStudents();
                        Console.WriteLine("Список студентов:");
                        for (int i = 0; i < students.Count; ++i)
                        {
                            Console.WriteLine(students[i]["Id"] + " "  + students[i]["Name"] + " " + students[i]["Speciality"] + " " + students[i]["Group"]);
                        }
                        break;

                    /// <summary>
                    /// Вывод гистограммы (распределение по специальностям)
                    /// </summary>
                    case '5':
                        var histogram = logic.GetSpecialityHistogram();
                        Console.WriteLine("Гистограмма (распределение по специальностям):");
                        foreach (var speciality1 in histogram)
                        {
                            Console.WriteLine($"{speciality1.Key}: {speciality1.Value}");
                        }
                        break;
                    default:
                        Console.WriteLine("Введите номер команды из представленного списка:");
                        break;
                }
            }
        }
    }
}